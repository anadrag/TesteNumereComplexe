﻿using System;


namespace TesteNumereComplexe
{
    class test
    {
        protected string rasp;
        protected string rasp2;



        public test()
        {
            rasp="";
            
        }
        public string Raspuns(string a)
        {
            rasp = a;
            return rasp;
        }
    }
}

﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TesteNumereComplexe.UnitTests
{
    [TestClass]
    public class testconjugat
    {
        [TestMethod]
        public void ConjugatulLui_asteptat()
        {
            //Arrange
            var complex = new TesteNumereComplexe(5, 3);
            //Act
            var conjugat = new TesteNumereComplexe(5, -3);
            //Assert
            Assert.IsTrue((complex.parte_reala == conjugat.parte_reala) && (complex.parte_imaginara == conjugat.parte_imaginara * (-1)));
        }
    }
}

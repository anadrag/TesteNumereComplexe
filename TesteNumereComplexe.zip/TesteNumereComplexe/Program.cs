﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TesteNumereComplexe
{
    class Program
    {
        static void Main(string[] args)
        {
            Complex aux = new Complex();
            Complex nr1 = new Complex(5, 7);
            Complex nr2 = new Complex(4, 3);
            Console.WriteLine(nr1.ToString());

            Console.WriteLine(nr2.ToString());
            Console.WriteLine("****************************************************************");
            Console.WriteLine("                          TESTE NUMERE COMPLEXE                 ");
            Console.WriteLine("****************************************************************");
            int punctaj = 0;
            var rand = new Random();

            Console.WriteLine("                          Testul nr 1                 ");
            Console.WriteLine("****************************************************************");

            int r1 = rand.Next(101);
            int r2 = rand.Next(101);
            if (r2 % 3 == 0)
                r2 = r2 * (-1);
            Console.WriteLine("Se dă numărul complex de mai jos: ");
            Complex nr3 = new Complex(r1, r2);
            Complex aux1 = nr3;

            // intrebarea 1

            Console.WriteLine("nr3=" + nr3.ToString());
            Console.WriteLine("    Cerinta 1:                ");
            Console.WriteLine("       a)   Re (z)=  {0}               ", r1);
            Console.WriteLine("       b)   Re (z)=  {0}               ", r2);

            string rasp, rasp2;
            Console.Write("răspunsul  corect este ( a sau b ): "); rasp = Console.ReadLine();
            rasp2 = rasp.Substring(0, 1);
            string RaspCorect = "a";

            /*test RaspCorect = new rasp();
            RaspCorect.Raspuns("a")*/
            if (RaspCorect == rasp2)
            {
                Console.WriteLine("DA");
                punctaj = punctaj + 5;
                Console.WriteLine("                             Ati acumulat 5 puncte ----->      deci in total   {0}   puncte", punctaj);
            }
            else
                Console.WriteLine("NU");

            // intrebarea 2

            Console.WriteLine("   ---------------------------------------------------          ");
            Console.WriteLine("    Cerinta 2:                ");
            Console.WriteLine("       a)   Im (z)=  {0}               ", r1);
            Console.WriteLine("       b)   Im (z)=  {0}               ", r2);

            Console.Write("răspunsul  corect este ( a sau b ): "); rasp = Console.ReadLine();
            rasp2 = rasp.Substring(0, 1);
            RaspCorect = "b";
            if (RaspCorect == rasp2)
            {
                Console.WriteLine("DA");
                punctaj = punctaj + 5;
                Console.WriteLine("                             Ati acumulat 5 puncte ----->      deci in total   {0}   puncte", punctaj);
            }
            else
                Console.WriteLine("NU");


            // intrebarea 3
            Console.WriteLine("   ---------------------------------------------------          ");


            Console.WriteLine("    Cerinta 3:                ");
            Console.WriteLine("         conjugatul lui " + nr3.ToString() + " este =  a+bi  unde ");
            int a, b;
            Console.Write("                                  a= "); a = int.Parse(Console.ReadLine());
            Console.Write("                                  b= "); b = int.Parse(Console.ReadLine());
            Complex conj = new Complex(a, b);
            Console.WriteLine("                                       " + conj.ToString());

            if (conj.Idem(nr3.ConjugatulLui(nr3)))
            {
                Console.WriteLine("DA");
                punctaj = punctaj + 5;
                Console.WriteLine("                             Ati acumulat 5 puncte ----->      deci in total   {0}   puncte", punctaj);
            }
            else
                Console.WriteLine("NU");
             
            // intrebarea 4
            Console.WriteLine("   ---------------------------------------------------          ");

            Console.WriteLine("    Cerinta 4:                ");
            nr3 = aux1;
            Console.WriteLine("          Opusul lui " + nr3.ToString() + "  este =    a+bi  unde    ");
            Console.Write("                                  a= "); a = int.Parse(Console.ReadLine());
            Console.Write("                                  b= "); b = int.Parse(Console.ReadLine());
            Complex opus = new Complex(a, b);
            Console.WriteLine("                                       " + opus.ToString());
            if (opus.Idem(nr3.OpusulLui(nr3)))
            {
                Console.WriteLine("DA");
                punctaj = punctaj + 5;
                Console.WriteLine("                             Ati acumulat 5 puncte ----->      deci in total   {0}   puncte", punctaj);
            }
            else
                Console.WriteLine("NU");




            /*
             * 
             * r1 = rand.Next(101);
            if (r1 % 6 == 0)
                r1 = r1 * (-1);

            r2 = rand.Next(101);
            Complex nr4 = new Complex(r1, r2);
            Console.WriteLine("nr4=" + nr4.ToString());


            Console.WriteLine("opusul lui nr3 =" + nr3.OpusulLui(nr3).ToString());
            Complex nr5 = new Complex();
            nr5.ConjugatulLui(nr3);
            Console.WriteLine("nr4= conjugatul lui nr3" + nr5.ToString());
            Console.WriteLine("nr3=" + nr3.ToString());
            /* aux = nr1 + nr2;
             Console.WriteLine(aux.ToString());

            aux = nr1 - nr2;
             Console.WriteLine(aux.ToString());

             aux = nr1 * nr2;
             Console.WriteLine(aux.ToString());

             aux = nr1 ^ 2;
             Console.WriteLine(aux.ToString());

             nr1.FormaTrigonometrica();


             ComplexD D = new ComplexD();
             Console.WriteLine(D.RidicareaCuFormaTrig(nr1,2));

             List<Complex> multime = new List<Complex>();

             multime.Add(new ComplexD(2, 4));
             multime.Add(new ComplexD(5, 2));
             multime.Add(new ComplexD(1, 1));
             D.Dist(multime);*/


            Console.ReadKey();
        }
    }
}




